<?php
return array(
  'elements'=>array(
      'user_id'=>array('type'=>'hidden'),
      'mobile_alert'=>array('type'=>'checkbox'),
      '<br>',
      'mobile'=>array('type'=>'text'),
      '<br>',
      'email_alert'=>array('type'=>'checkbox'),
      '<br>',
      'email'=>array('type'=>'text'),
  ),
);
?>
