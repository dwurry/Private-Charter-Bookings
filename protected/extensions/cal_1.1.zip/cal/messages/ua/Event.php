<?php
return array(
    'Title'=>'Повідомлення',
    'Start'=>'Початок',
    'End'=>'Кінець',
    'All Day'=>'Весь день',
    'Editable'=>'Редагується',
);
?>
